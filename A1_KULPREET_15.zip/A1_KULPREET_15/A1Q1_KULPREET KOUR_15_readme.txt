Q1 The program is to calculate the expected displacement between the intial and final position of the bee.
Q2 The program is to also calculate the expected standard deviation in it.


We have included iostream file for input and output instruction.
We have included stdlib file for random number generation.
We have included time file for time (null) function.
We have included math file for math function such as sqrt.


float x and y store the position of bee and we have used float for this because we can take some decimal value as the position of the bee also like (0,0)  , (1.3,1.3)  and so on.
We have choosed the two dimensional figure to dipict the movement of bee where the bee is moving in positive x axis ,positive y axis ,
positive xy axis ,negative xy axis ,positive x and negative y axis and positive y and negative x axis.

The bee is moving from one hexagon to the other hexagon.
The movement from one hexagon to other is taken as one unit.
Since we have taken the movement of the bee in 2D figure the data structure used is graph where the centre of the hexagon is at (0,0)and all the sides of the hexagon lies in the x axis and y axis. 
Since the center of the hexagon is taken as the starting point of the bee movement and it can be moving in any direction in the 2d figure 
i.e. in x-y direction so we can change the starting point of the bee to some other number either positive or negative.

In the given question all the hexagon are tightly packed with each other in a tessalating structure and we have assumed that structure to be in xy plane.

In the program we have taken mcase variable to store some different possibiltiy of the bee movement in the xy plane.
the variable k is used in the for loop and runs till n i.e the number of times the bee is moving 16/64 steps in the tessalating structure.
THe variable i is also used in the for loop and runs till the number of steps the bee is moving in the structure i.e. 16 or 64 as asked in the question.
the array a[k] has float data type which stores displacemenet i.e. the explected value of the displacement between the bee's intial and final position,
for calculating displacement we have taken the formula as sqrt((x2-x1)^2 - (y2-y1)^2)
the variable sum is used to find the mean of all the displacement and in this we are adding the value of  all the displacement .
srand (time (null)) function generates the  different random number every time the program is executed.
rand()%7 +1 generates the random number between 1 to 8 as we have 8 cases defined for the movement of bee.

To depict the cases we have used switch  as in this the value of bee's positon can be incremented in any direction in 2d figure.
case 1 says that the value can be increase in positive y diection that can be taken as one of the nodes of the hexagon.
case 2 says that the bee can be moving in negative y direction.
case 3 suggest that the bee can be moving in negative x direction.
case 4 suggest that the bee can move in positive x and positive y direction 
case 5 says that the bee can move in negative x direction and positive y direction.
case 6 says that the bee is moving in positive x direction.
case 7 says that the bee is moving in negative y and negative x direction.
case 8 says that the bee is moving in positive x direction and negative y direction.

The variable double mean is storing mean value of all the displacement.
The variable l used in for loop and runs till n  is to fetch the value of displacement from the array a[k] to calculate standard deviation and stores in the variable m of datatype float.
the variable var is storing variance .
the variable sd stores the standard deviation.




example:


                                   +yaxis
                                   __|___    
                                  |  |   |
                     -x axis  ___|___|____|_____ +x axis                                    
                                  |  |(0,0)|the bee is starting from this point
                                   |_|___|
                                     |
                                    -y axis      

logic 1 is such that the bee stats moing from the center of the hexagon and we have assumed it to be at (0,0) and moves in +ive y axis and +ive x axis 
then the value of of x increement to be (1,1) and the bee moves 16 steps in the same direction so finally the final position of bee is (16,16).
the displacement is  sqrt((16-0)^2 + (16-0)^2)
                   =sqrt(256+256)
                   =sqrt(512)
                   approx 22

Since this question has runned first time and can be run it many times as 20 , 30 and so on the different possible value of displacement generated is stored and mean value is kept safely.
now this dispalcement value is stored in a[k] and summed upto n(means k is running from 0 to n-1) in sum variable and 
then to calculate the mean=sum/n where n is number of times the bee is moving 16 steps is stored in mean variable.
and then mean is used to caclulate the variance = (standard deviation)^2.

variance = (xi-mean)^2 where xi is from 0 to n-1 where n can be 10, 20, or any positive number.

This means the value of (xi-mean) is adding from 0 till 19 and then dividing by n-1. this gives us variance.

  
Now this logic 1 can be interpreted to 64 steps also as asked in the question with same value of n.


output:when the program is running 20 times for the bee moving 16 steps in any direction taking random variable


 expected displacement
0, 6.7082
1, 7.61577
2, 9.8995
3, 8
4, 5.65685
5, 9.21954
6, 2.23607
7, 3
8, 4.24264
9, 4.24264
10, 4
11, 4
12, 1.41421
13, 9.21954
14, 6.32456
15, 8.48528
16, 1.41421
17, 2.82843
18, 5.38516
19, 3

expected mean value 5.34463
expected standard deviation is  2.71156
 