#include <iostream>                               //for input,output 
#include <stdlib.h>                              //for srand, rand 
#include <time.h>                                // for time 
#include <math.h>                                //for math functions 
using namespace std;
//int n=0;
int main()
{
float x, y;                                   // the bee is moving in any direction but in 2d form and to store the value of bee movement we have choseen the variables x and y 
                                              //suppose x and y are (0, 0).
int mcase;                                    //to define the movement of bee in 2d form
int k,i;                                     
//float displacement;
float sum;
int n=20;                                       
float a[n];                                   //to store the value of displacement in the array to calculate the standard deviation.
    srand (time(NULL));                        //this will generate new random numbers every time the program is executed.
//cout<<"enter the value for the no. of times you want to execute the bee's movement "<<endl;
//cin>>n;
cout <<endl<< " expected displacement  " <<endl;
for(k=0;k<n;k++)                           //since this program is running for 20 times we can change the value of this to 10 , 30, 40, and so on.
{
x = y = 0;                                    //we can change the intial coordinates of the x any y i.e. the bee's intial point to say 10,10, 20,20.
for(i=0;i<16;i++)                             //since the bee is moving 16 steps and then we have calculated the 
                                             //displacement we can change the value of this or the the no. of steps bee has moved to 64 as asked in the question.                       
{
	
    mcase = rand() % 7 + 1;                         //this will generate random no. from 1 to 7. this is done because the movement of bee can be in any direction of the hexagon including its six sides
                                                   //and also in positive y axis alone and negative y axis alone. 
switch(mcase)
{
case 1:
y++;
break;
case 2:
y--;
break;
case 3:
x--;
break;
case 4:
x++; y++;
break;
case 5:
x--, y++;
break;
case 6:
x++;
break;
case 7:
y--; x--;
break;
case 8:
x++; y--;
break;
}
}
a[k] = sqrt((0-x)*(0-x) + (0-y)*(0-y));    //here we are calculating displacement between intial and final position of bee. 
cout <<k<<", " <<a[k]<<endl;
//a[k]=displacement;                               //here we have taken these displacement values as x to find the standard deviaton.
sum = sum + a[k];
}
cout<<endl;
//cout<<"n"<<n<<endl<<endl;
double mean=sum/n;
cout << "expected mean value " << mean << endl;
float m=0;
//cout<<"n"<<n<<endl<<endl;
for(int l=0;l<n;l++)                         // this is to fetch the value of displacement from the array a[k] to calculate standard deviation.
{
 //cout<<"n"<<n<<"  ";
	m=m+(a[l]-mean)*(a[l]-mean);
//	cout<<m<<"  ";
}
//cout<<endl<<"n"<<n<<endl<<endl;
//cout<<"m"<<m<<endl<<endl;
double var=m/(n-1);
//cout<<var<<endl<<endl;
double sd=sqrt(var);
cout<<"expected standard deviation is"<<"  "<<sd<<endl;
return 0;
}

